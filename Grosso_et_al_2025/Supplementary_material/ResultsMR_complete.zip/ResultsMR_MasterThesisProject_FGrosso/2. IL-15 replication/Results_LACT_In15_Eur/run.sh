#!/bin/bash
Rscript -e "library(R.utils)"
# Percorso del file R da eseguire
R_script="E_LACT_In15_REP.R"
# Percorso della cartella contenente i file di esposizione
exposure_file="/home/students/federica.grosso/nas/microbiome/Clumping_results_no_NA/clumping_GCST90027488.csv"
# Percorso della cartella contenente i file di outcome
outcome_file="/home/students/federica.grosso/nas/microbiome/Outcomes/Interleukin-15/merged_IL15RA.14054.17.3_build37.txt"

Rscript "$R_script" "$exposure_file" "$outcome_file"
