#!/bin/bash
Rscript -e "library(R.utils)"
# Percorso del file R da eseguire
R_script="E_Bif.ado_GCST90032220_O_TNFSF12_GCST90274846.R"
# Percorso della cartella contenente i file di esposizione
exposure_file="clumping_GCST90032220.csv"
# Percorso del file di outcome
file_path_outcome="/home/students/federica.grosso/nas/microbiome/Outcomes/Inflammatory proteins/GCST90274846.tsv"
# Ciclo su tutti i file di esposizione nella cartella
Rscript "$R_script" "$exposure_file" "$file_path_outcome"

