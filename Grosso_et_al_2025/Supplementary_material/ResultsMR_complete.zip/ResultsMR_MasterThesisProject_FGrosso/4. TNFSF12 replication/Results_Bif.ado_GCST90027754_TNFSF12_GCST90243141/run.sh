#!/bin/bash
Rscript -e "library(R.utils)"
# Percorso del file R da eseguire
R_script="E_Bif.ado_GCST90027754_O_TNFSF12_GCST90243141.R"
# Percorso della cartella contenente i file di esposizione
exposure_file="/home/students/federica.grosso/nas/microbiome/Clumping_results_no_NA/clumping_GCST90027754.csv"
# Percorso del file di outcome
file_path_outcome="/home/students/federica.grosso/nas/microbiome/Outcomes/TNFSF12/merged_TNFSF12.5939.42.3.txt"
# Ciclo su tutti i file di esposizione nella cartella
Rscript "$R_script" "$exposure_file" "$file_path_outcome"



