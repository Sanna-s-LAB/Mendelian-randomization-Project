#!/bin/bash
Rscript -e "library(R.utils)"
# Percorso del file R da eseguire
R_script="E_LACT_O_TRAIL.R"
# Percorso della cartella contenente i file di esposizione
exposure_file="/home/students/federica.grosso/nas/microbiome/Clumping_results_no_NA/clumping_GCST90027488.csv"
# Percorso del file di outcome
file_path_outcome="/home/students/federica.grosso/nas/microbiome/Outcomes/TRAIL/merged_GCST90012011_buildGRCh37.txt"
# Ciclo su tutti i file di esposizione nella cartella
Rscript "$R_script" "$exposure_file" "$file_path_outcome"

