# Load necessary libraries
library(dplyr)
library(openxlsx)
library(readxl)

# Directory containing CSV files
directory <- "/home/students/federica.grosso/nas/microbiome/Other_analysis/Replications/Results_Fingen/"

# Get the list of CSV files in the directory
files <- list.files(directory, pattern = "\\.csv$", full.names = TRUE)

# Initialize an empty list to store the data frames
df_list <- list()

# Read each CSV file and store it in the list
for (file in files) {
  df <- read.csv(file, header = TRUE, stringsAsFactors = FALSE)
  df_list[[file]] <- df
}

# Merge all data frames by row-binding and retaining all columns
merged_df <- bind_rows(df_list, .id = "source_file")

# Remove columns that contain "ple" or "het" in their names
merged_df <- merged_df %>% select(-any_of(c("ple", "het")))

# Save the merged file temporarily
output_file_xlsx <- paste0(directory, "merged_MR_Finngen.xlsx")
write.xlsx(merged_df, output_file_xlsx)

# Now apply the p-value correction
# Subset the dataset for the required methods
datasub <- subset(merged_df, method %in% c("Inverse variance weighted", "Wald ratio"))

# Applica la correzione BH sui p-value
datasub$pval_adj <- p.adjust(datasub$pval, method = "BH", n = length(datasub$pval))
  
#Unisci i dati originali con i p-value corretti, evitando nomi di colonne duplicati
merged_data <- merge(merged_df, datasub %>% select(source_file, method, pval_adj), by = "source_file", all = TRUE)
if ("method.x" %in% colnames(merged_data)) {
  merged_data <- merged_data %>%
    rename(method = method.x) %>%
    select(-method.y)
}
merged_data <- merged_data %>%
  select(source_file, everything())
# Rearrange the columns: move pval_adj to the last position
#pval_adj_index <- grep("pval_adj", colnames(merged_data))  # Find the index of 'pval_adj'
#other_columns <- setdiff(1:ncol(merged_data), pval_adj_index)  # All columns except 'pval_adj'
#merged_data <- merged_data[, c(other_columns[1:(length(other_columns)-1)], pval_adj_index, other_columns[length(other_columns)])]


#merged_data <- merged_data %>%
#  relocate(1, .before = "egger_intercept.ple")  
# Write the final dataset to an Excel file
final_output <- paste0(directory, "merged_MR_Finngen_corrected.xlsx")
write.xlsx(merged_data, final_output)

cat("Merging, column removal, and p-value adjustment completed. File created:", final_output, "\n")
