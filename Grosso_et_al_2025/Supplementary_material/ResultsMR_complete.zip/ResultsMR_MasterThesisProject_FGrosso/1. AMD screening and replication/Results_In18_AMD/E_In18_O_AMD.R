library(dplyr)
require(TwoSampleMR)
require(ieugwasr)
require(ggplot2)
require(MRPRESSO)
library(officer)
source("/home/students/federica.grosso/nas/funzioni.R")
# Leggi il percorso del file dalla linea di comando
args <- commandArgs(trailingOnly = TRUE)
file_path_exposure <- args[1]
file_path_outcome <- args[2]

# RICAVA NOME EXPOSURE
nome_fileE <- basename(file_path_exposure)
nome_file_senza_ext <- tools::file_path_sans_ext(nome_fileE)
# Divide il nome del file basandosi sul carattere "_"
parti_nome <- strsplit(nome_file_senza_ext, "_")[[1]]
nome_exposure <- paste(parti_nome[2])

# RICAVA NOME OUTCOME
nome_outcome <- "AMD"

base_path <- "/home/students/federica.grosso/nas/microbiome/Other_analysis/Results_In18_AMD/"

dataE<-read.csv(file_path_exposure, header=T)
suppressWarnings({
  dataO<-read_outcome_data(file_path_outcome, 
                           snps = dataE$SNP,
                           sep="\t", 
                           phenotype_col = "Outcome",
                           snp_col = "variant_id",
                           beta_col = "beta",
                           se_col="standard_error",
                           eaf_col = "effect_allele_frequency",
                           effect_allele_col = "effect_allele",
                           other_allele_col = "other_allele",
                           pval="p_value",
						   samplesize_col="N")
  dataO$outcome <- "AMD"
})

# HARMONIZE
output_file <- paste0(base_path,"Harm_data_E_", nome_exposure, "_O_", nome_outcome, ".txt")
dat <- harmonise_data(dataE, dataO, action = 2)
write.table(dat, file = output_file, sep = "\t", quote=F)

# MR RESULTS
#output_file <- paste0(output_file <- paste0(base_path,"MR_E_", nome_exposure, "_O_", nome_outcome, ".csv")
mr_results <- mr(dat, method_list = c("mr_egger_regression", "mr_ivw","mr_wald_ratio","mr_weighted_median"))
#write.csv(mr_results, file = output_file, quote=F, row.names = F)
# wald solo quando ho solo uno SNP, il p di significatività è 0.05

# Sensitivity analysis
# Crea un nome di file unico per il file di output (puoi modificare questa parte come preferisci)
#output_file <-  paste0(base_path,"Het_E_", nome_exposure, "_O_", nome_outcome, ".txt")
het<-mr_heterogeneity(dat, method_list="mr_ivw")
#write.table(het, file = output_file, sep = "\t", quote=F)

#cat("\n\n--- Pleiotropy ---\n\n", file = output_file, append = TRUE)
#output_file <-  paste0(base_path,"Ple_E_", nome_exposure, "_O_", nome_outcome, ".txt")
ple <- mr_pleiotropy_test(dat)
#write.table(ple, file = output_file, sep = "\t", quote=F)

output_file <- paste0(base_path,"SINGLESNP_E_", nome_exposure, "_O_", nome_outcome, ".txt")
res_single <- mr_singlesnp(dat)
write.table(res_single, file = output_file, sep = "\t", quote=F)

output_file <- paste0(base_path,"LOO_E_", nome_exposure, "_O_", nome_outcome, ".txt")
res_loo <- mr_leaveoneout(dat)
write.table(res_loo, file = output_file, sep = "\t", quote=F)


# PLOTS

## Scatter plot
output_file <- paste0(base_path,"plots_E_", nome_exposure, "_O_", nome_outcome, ".pdf")
pdf(output_file)

p1<-mr_scatter_plot(mr_results,dat)
#title("Scatter Plot")
print(p1)

## Forest plot

p2 <- mr_forest_plot(res_single)
#title("Forest Plot")
print(p2)

## Leave-one-out plot

p3 <- mr_leaveoneout_plot(res_loo)
#title("Leave-One-Out Plot")
print(p3)

## Funnel plot
## Asymmetry in a funnel plot is useful for gauging the reliability of a particular MR analysis

p4 <- mr_funnel_plot(res_single)
#title("Funnel Plot")
print(p4)

dev.off()


mr_presso <- tryCatch({
  result <- mr_presso(BetaOutcome="beta.outcome", 
                      BetaExposure="beta.exposure", 
                      SdOutcome="se.outcome", 
                      SdExposure="se.exposure", 
                      data=dat, 
                      OUTLIERtest = TRUE, 
                      DISTORTIONtest = TRUE, 
                      SignifThreshold = 0.05, 
                      NbDistribution = 1000, seed = 1)
  result  # Ritorna il risultato se non ci sono errori
}, error = function(e) {
  # Gestisci l'errore
  cat("Errore nell'esecuzione di mr_presso:", e$message, "\n")
  NULL  # Assegna NULL se c'è un errore
})

output_file <- paste0(base_path,"MRallRES_E_", nome_exposure, "_O_", nome_outcome, ".csv")
# Verifica se mr_presso non è NULL
if (!is.null(mr_presso)) {
  # Aggiungi una nuova riga a mr_results
  mr_results[nrow(mr_results) + 1, ] <- mr_results[nrow(mr_results), ] 
  
  # Verifica se ci sono indici di outlier nel test di distorsione
  if (!is.null(mr_presso$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`)){
    mr_results[nrow(mr_results), "nsnp"] <- mr_results$nsnp[1]- length(mr_presso$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`)
  } else {
    mr_results[nrow(mr_results), "nsnp"] <- mr_results$nsnp[1]
  }
  
  # Assegna i valori ai metodi e ai risultati principali
  mr_results[nrow(mr_results), "method"] <- "MR-PRESSO"
  mr_results[nrow(mr_results), "b"] <- mr_presso$`Main MR results`$`Causal Estimate`[1]
  mr_results[nrow(mr_results), "se"] <- mr_presso$`Main MR results`$Sd[1]
  mr_results[nrow(mr_results), "pval"] <- mr_presso$`Main MR results`$`P-value`[1]
} else {
  # Aggiungi una nuova riga a mr_results e assegna valori NA se mr_presso è NULL
  mr_results[nrow(mr_results) + 1, ] <- mr_results[nrow(mr_results), ] 
  mr_results[nrow(mr_results), "method"] <- "MR-PRESSO"
  mr_results[nrow(mr_results), "b"] <- NA
  mr_results[nrow(mr_results), "se"] <- NA
  mr_results[nrow(mr_results), "pval"] <- NA
}
# Se 'ple' non è nullo e ha più di 0 righe e colonne, rinomina e aggiungi NA se necessario
if (!is.null(ple) && nrow(ple) > 0 && ncol(ple) > 0){
  ple <- ple %>%
    rename_with(~paste0(., ".ple"))
  while(nrow(ple) < nrow(mr_results)) {
    ple[nrow(ple) + 1, ] <- NA
  }
} else {
  # Create a new dataframe with a single column 'ple' and 4 rows of NA
  ple <- data.frame(ple = rep(NA, nrow(mr_results)))
}
if (!is.null(het) && nrow(het) > 0 && ncol(het) > 0) {
  het <- het %>%
    rename_with(~ paste0(.,".het"))
  while(nrow(het) < nrow(mr_results)) {
    het[nrow(het) + 1, ] <- NA
  }
} else  {
  # Create a new dataframe with a single column 'ple' and 4 rows of NA
  het <- data.frame(het = rep(NA, nrow(mr_results)))
}


final <- cbind(mr_results,ple,het)
final <- final[, !colnames(final) %in% c("id.exposure.ple", "id.outcome.ple","outcome.ple","exposure.ple","method.het","id.exposure.het", "id.outcome.het","outcome.het","exposure.het")]

filtered_variants <- dat$SNP[dat$mr_keep != FALSE]
# Crea una stringa con le varianti filtrate, separate da punto e virgola
all_filtered_variants <- paste(filtered_variants, collapse = "; ")
# Aggiungi una nuova colonna a 'final' con tutte le varianti filtrate in una sola cella per ogni riga
final$IV_list <- rep(all_filtered_variants, nrow(final))

outliers_indices <- mr_presso$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`

# Ensure outliers_indices is handled properly
if (!is.null(outliers_indices) &
    length(outliers_indices) > 0 &
    !any(is.na(outliers_indices)) & 
    all(outliers_indices != "No significant outliers")) {
  
  # Convert indices to integer and remove corresponding variants
  outliers_indices <- as.integer(outliers_indices)
  filtered_variants_no_outliers <- filtered_variants[-outliers_indices]
  
  # Create a string with variants without outliers
  all_filtered_variants_no_outliers <- paste(filtered_variants_no_outliers, collapse = "; ")
  
  # Assign the list of variants without outliers to IV_list column
  final$IV_list[nrow(final)] <- all_filtered_variants_no_outliers
} else {
  # If there are no outliers, assign the full list of variants
  final$IV_list[nrow(final)] <- all_filtered_variants
}

write.csv(final, file = output_file, quote=F, row.names = F)

output_file <- paste0(base_path,"MR_PRESSO/MR_PRESSO_E_", nome_exposure, "_O_", nome_outcome, ".docx") 
doc <- read_docx()
doc <- doc %>%
  body_add_par("MR Presso results:", style = "heading 1")

# Aggiungi i risultati di 'Main MR results'
if (!is.null(mr_presso$`Main MR results`)) {
  doc <- doc %>%
    body_add_par("Main MR results:", style = "heading 2") %>%
    body_add(mr_presso$`Main MR results`)}

# Aggiungi i risultati di 'MR-PRESSO results'
if (!is.null(mr_presso$`MR-PRESSO results`$`Outlier Test`)) {
  doc <- doc %>%
    body_add_par("MR-PRESSO results:", style = "heading 2") %>%
    body_add_par("Outlier test:", style = "heading 3") %>%
    body_add(mr_presso$`MR-PRESSO results`$`Outlier Test`)}

# Aggiungi i risultati di 'MR-PRESSO results'
if (!is.null(mr_presso$`MR-PRESSO results`$`Global Test`$RSSobs)) {
  doc <- doc %>%
    body_add_par("Global test - RSSobs:", style = "heading 3") %>%
    body_add(mr_presso$`MR-PRESSO results`$`Global Test`$RSSobs)}

# Aggiungi i risultati di 'MR-PRESSO results'
if (!is.null(mr_presso$`MR-PRESSO results`$`Global Test`$Pvalue)) {
  doc <- doc %>%
    body_add_par("Global test - Pvalue:", style = "heading 3") %>%
    body_add(mr_presso$`MR-PRESSO results`$`Global Test`$Pvalue)}

# Aggiungi i risultati di 'MR-PRESSO results'
if (!is.null(mr_presso$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`) &  all(outliers_indices != "No significant outliers")) {
  doc <- doc %>%
    body_add_par("Distortion Test - Outlier indices:", style = "heading 3") %>%
    body_add(mr_presso$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`)}

if (!is.null(mr_presso$`MR-PRESSO results`$`Distortion Test`$`Distortion Coefficient`) &  !any(is.na(mr_presso$`MR-PRESSO results`$`Distortion Test`$`Distortion Coefficient`))) {
  doc <- doc %>%
    body_add_par("Distortion Test - Distortion Coefficient:", style = "heading 3") %>%
    body_add(mr_presso$`MR-PRESSO results`$`Distortion Test`$`Distortion Coefficient`)}

if (!is.null(mr_presso$`MR-PRESSO results`$`Distortion Test`$Pvalue) & !any(is.na(mr_presso$`MR-PRESSO results`$`Distortion Test`$Pvalue))) {
  doc <- doc %>%
    body_add_par("Distortion Test - Pval:", style = "heading 3") %>%
    body_add(mr_presso$`MR-PRESSO results`$`Distortion Test`$Pvalue)}
# Salva il documento Word
print(doc, target = output_file)



outliers_removed <- mr_presso$`MR-PRESSO results`$`Distortion Test`$`Outliers Indices`
# Aggiungi una nuova colonna a `dat` per indicare se un SNP è un outlier
dat$outlier_status <-  ifelse(seq_along(dat$SNP) %in% outliers_removed, "Removed", "Kept")

# Filtra il dataset per includere solo gli SNP mantenuti
dat_kept <- subset(dat, outlier_status == "Kept")
dat_removed <- subset(dat, outlier_status == "Removed")
mr_results_kept <- mr(dat_kept, method_list = c("mr_egger_regression", "mr_ivw","mr_wald_ratio","mr_weighted_median"))
output_file <-paste0(base_path,"MR_PRESSO/MR_PRESSO_E_", nome_exposure, "_O_", nome_outcome, ".pdf")
pdf(output_file)
p1 <- mr_scatter_plot_col(mr_results,dat,dat_kept,dat_removed)
print(p1)
p2 <- mr_scatter_plot_IVW(mr_results,mr_results_kept,dat,dat_kept,dat_removed)
print(p2)
dev.off()

rm(list = ls())