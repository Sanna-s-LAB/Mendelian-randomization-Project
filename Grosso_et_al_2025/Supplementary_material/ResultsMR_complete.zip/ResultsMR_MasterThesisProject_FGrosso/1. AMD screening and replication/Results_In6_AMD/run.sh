#!/bin/bash
Rscript -e "library(R.utils)"
# Percorso del file R da eseguire
R_script="/home/students/federica.grosso/nas/microbiome/Other_analysis/Results_In6_AMD/E_In6_O_AMD.R"
# Percorso della cartella contenente i file di esposizione
exposure_file="/home/students/federica.grosso/nas/microbiome/ReverseMR/clumping_In6.csv"
# Percorso del file di outcome
file_path_outcome="/home/students/federica.grosso/nas/microbiome/Outcomes/Macular degeneration age-related/362.29_PheCode.v1.0.fastGWA.tsv"
# Ciclo su tutti i file di esposizione nella cartella
Rscript "$R_script" "$exposure_file" "$file_path_outcome"

